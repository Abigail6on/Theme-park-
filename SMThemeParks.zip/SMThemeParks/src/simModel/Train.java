package simModel;

public class Train {
	//AttributesW
	int[] numPassengers = new int[4];
	boolean boarding;
	int capacity;

}
