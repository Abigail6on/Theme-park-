package simModel;

class Constants {
	
	// Define constants as static
	final static int FROG = 0;
	final static int SKUNK = 1;
	final static int GATOR = 2;
	final static int RACCOON = 3;

}
