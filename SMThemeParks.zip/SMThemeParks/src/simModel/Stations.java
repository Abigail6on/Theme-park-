package simModel;

public class Stations {
	int n; //number of Passengers waiting to board a train

}